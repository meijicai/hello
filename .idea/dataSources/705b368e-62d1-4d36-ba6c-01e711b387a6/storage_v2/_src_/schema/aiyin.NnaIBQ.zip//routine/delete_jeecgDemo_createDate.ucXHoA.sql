CREATE PROCEDURE delete_jeecgDemo_createDate(IN createDate DATE)
  BEGIN 
  delete from jeecg_demo where create_date >= createDate;
END;

