CREATE PROCEDURE formDataList(IN tableName VARCHAR(50), IN dbFields VARCHAR(500), IN whereSql VARCHAR(1000))
  BEGIN
	declare exe_sql varchar(2000);
	SET exe_sql = CONCAT("select ",dbFields," from ",tableName,whereSql);
	set @v_sql=exe_sql;   
	prepare stmt from @v_sql; 
	EXECUTE stmt;     
	deallocate prepare stmt; 
END;

